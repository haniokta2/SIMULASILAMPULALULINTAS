#!/usr/bin/env python3
"""Server lokal untuk simulator (port 3000) dan HMI (port 7001).

Hanya pustaka standar Python. Keduanya berbagi satu state di memori:
- simulator.html mengirim `status` (fase, jumlah mobil) dan menerima `config`
- hmi.html membaca `status` dan mengubah `config`
Perubahan config hanya diterima lewat port HMI.
"""
import json
import threading
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SIM_PORT, HMI_PORT = 3000, 7001

LOCK = threading.Lock()
STATE = {
    "config": {"density": 8, "green": 8, "yellow": 2, "allred": 2,
               "paused": False, "mode": "auto", "reset": 0},
    "status": {},
    "status_ts": 0.0,
}
LIMITS = {"density": (3, 14), "green": (4, 20), "yellow": (1, 5), "allred": (1, 5)}
STATUS_KEYS = {"phase", "NS", "EW", "waiting", "thru", "cars", "t", "dur"}


def clean_config(patch):
    out = {}
    for key, (lo, hi) in LIMITS.items():
        if key in patch:
            try:
                out[key] = max(lo, min(hi, int(patch[key])))
            except (TypeError, ValueError):
                pass
    if "paused" in patch:
        out["paused"] = bool(patch["paused"])
    if patch.get("mode") in ("auto", "allred"):
        out["mode"] = patch["mode"]
    if "reset" in patch:
        try:
            out["reset"] = int(patch["reset"])
        except (TypeError, ValueError):
            pass
    return out


def clean_status(raw):
    out = {}
    for key in STATUS_KEYS:
        v = raw.get(key)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            out[key] = v
        elif isinstance(v, str):
            out[key] = v[:40]
    return out


def make_handler(default_page, allow_config):
    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *a, **k):
            super().__init__(*a, directory=str(ROOT), **k)

        def end_headers(self):
            self.send_header("Cache-Control", "no-store")
            super().end_headers()

        def _json(self, code, obj):
            body = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _snapshot(self):
            with LOCK:
                return {"config": dict(STATE["config"]),
                        "status": dict(STATE["status"]),
                        "age": round(time.time() - STATE["status_ts"], 1) if STATE["status_ts"] else None}

        def do_GET(self):
            path = self.path.split("?")[0]
            if path == "/api/state":
                return self._json(200, self._snapshot())
            if path in ("/", "/index.html"):
                self.path = "/" + default_page
            elif path not in ("/simulator.html", "/hmi.html"):
                return self.send_error(404)   # jangan sajikan server.py dll.
            return super().do_GET()

        def do_POST(self):
            if self.path.split("?")[0] != "/api/state":
                return self.send_error(404)
            try:
                size = int(self.headers.get("Content-Length", 0))
                if size > 4096:
                    return self._json(413, {"error": "terlalu besar"})
                data = json.loads(self.rfile.read(size) or b"{}")
                if not isinstance(data, dict):
                    raise ValueError
            except (ValueError, json.JSONDecodeError):
                return self._json(400, {"error": "JSON tidak valid"})
            with LOCK:
                if isinstance(data.get("status"), dict):
                    STATE["status"] = clean_status(data["status"])
                    STATE["status_ts"] = time.time()
                if allow_config and isinstance(data.get("config"), dict):
                    STATE["config"].update(clean_config(data["config"]))
            return self._json(200, self._snapshot())

        def log_message(self, *args):
            pass

    return Handler


if __name__ == "__main__":
    for port, page, allow in ((SIM_PORT, "simulator.html", False),
                              (HMI_PORT, "hmi.html", True)):
        srv = ThreadingHTTPServer(("127.0.0.1", port), make_handler(page, allow))
        threading.Thread(target=srv.serve_forever, daemon=True).start()
    print(f"Simulator: http://localhost:{SIM_PORT}")
    print(f"HMI      : http://localhost:{HMI_PORT}")
    print("Ctrl+C untuk berhenti")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass
